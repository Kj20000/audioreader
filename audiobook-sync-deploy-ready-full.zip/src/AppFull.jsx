import React, { useState, useRef, useEffect, useCallback } from "react";

/*
AudiobookSyncApp.jsx (AppFull.jsx)
Full-featured single-file React component implementing:
- Folder picker (showDirectoryPicker) to select book folder
- Auto-detect epub/pdf and mp3/m4a; create 'project'
- Audio player with controls (play/pause, seek, forward/back, speed)
- Earphone / MediaSession support
- EPUB rendering (using ePub.js) and PDF rendering (pdfjs-dist)
- Highlighting via timestamp mapping (.json or .srt like) and manual sync
- Manual mapping creation saved back to folder (File System Access API)
- Adjustable typography, themes, scroll/page modes
- Bookmarks, notes (timestamped), local cache via IndexedDB (idb-keyval)
- PWA-ready structure notes (manifest + service worker placeholders)

NOTE: This file lazy-imports heavy libs when needed.
*/

export default function AppFull() {
  const [project, setProject] = useState(null);
  const [theme, setTheme] = useState("light");
  const [fontSize, setFontSize] = useState(18);
  const [lineHeight, setLineHeight] = useState(1.6);
  const [mode, setMode] = useState("scroll"); // 'scroll' or 'paged'
  const [speed, setSpeed] = useState(1.0);
  const [playbackState, setPlaybackState] = useState("paused");
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [mapping, setMapping] = useState(null); // array of {start, end, locator}
  const [bookmarks, setBookmarks] = useState([]);
  const [notes, setNotes] = useState([]);

  const audioRef = useRef(null);
  const epubRef = useRef(null);
  const renditionRef = useRef(null);
  const pdfContainerRef = useRef(null);
  const pdfDocumentRef = useRef(null);
  const rafRef = useRef(null);
  const directoryHandleRef = useRef(null);

  async function pickFolderAndLoad() {
    if (!window.showDirectoryPicker) {
      alert("Your browser does not support the File System Access API. Use Chrome/Edge or enable the feature.");
      return;
    }

    try {
      const dir = await window.showDirectoryPicker();
      directoryHandleRef.current = dir;

      const entries = {};
      for await (const [name, handle] of dir) {
        const lower = name.toLowerCase();
        if (handle.kind === "file") {
          entries[lower] = { name, handle };
        }
      }

      const audioExts = [".mp3", ".m4a", ".aac", ".wav", ".ogg", ".m4b"];
      const epubExts = [".epub"];
      const pdfExts = [".pdf"];
      const jsonExts = [".json", ".srt", ".vtt"];

      let audioFile = null, epubFile = null, pdfFile = null, syncFile = null;

      for (const key in entries) {
        if (!audioFile && audioExts.some(ext => key.endsWith(ext))) audioFile = entries[key];
        if (!epubFile && epubExts.some(ext => key.endsWith(ext))) epubFile = entries[key];
        if (!pdfFile && pdfExts.some(ext => key.endsWith(ext))) pdfFile = entries[key];
        if (!syncFile && jsonExts.some(ext => key.endsWith(ext))) syncFile = entries[key];
      }

      const proj = { dir, audioFile, epubFile, pdfFile, syncFile };
      setProject(proj);

      if (proj.syncFile) {
        const file = await proj.syncFile.handle.getFile();
        const text = await file.text();
        try {
          const parsed = JSON.parse(text);
          setMapping(parsed);
        } catch (e) {
          const parsed = parseSRTorVTT(text);
          setMapping(parsed);
        }
      }

      if (proj.audioFile) await loadAudioHandle(proj.audioFile.handle);
      if (proj.epubFile) await loadEPUBHandle(proj.epubFile.handle);
      else if (proj.pdfFile) await loadPDFHandle(proj.pdfFile.handle);

    } catch (err) {
      console.error(err);
      alert("Could not open folder: " + (err.message || err));
    }
  }

  async function loadAudioHandle(fileHandle) {
    const file = await fileHandle.getFile();
    const url = URL.createObjectURL(file);
    if (!audioRef.current) audioRef.current = new Audio();
    audioRef.current.src = url;
    audioRef.current.preload = "metadata";
    audioRef.current.playbackRate = speed;

    audioRef.current.onloadedmetadata = () => {
      setDuration(audioRef.current.duration || 0);
    };

    audioRef.current.ontimeupdate = () => {
      setCurrentTime(audioRef.current.currentTime);
    };

    audioRef.current.onplay = () => setPlaybackState("playing");
    audioRef.current.onpause = () => setPlaybackState("paused");

    if (navigator.mediaSession) {
      try {
        navigator.mediaSession.metadata = new window.MediaMetadata({ title: project?.epubFile?.name || project?.pdfFile?.name || "Audio" });
      } catch (e) {}
      navigator.mediaSession.setActionHandler('play', () => audioRef.current.play());
      navigator.mediaSession.setActionHandler('pause', () => audioRef.current.pause());
      navigator.mediaSession.setActionHandler('seekbackward', () => seekRelative(-10));
      navigator.mediaSession.setActionHandler('seekforward', () => seekRelative(10));
    }
  }

  function seekRelative(seconds) {
    if (!audioRef.current) return;
    audioRef.current.currentTime = Math.max(0, Math.min(audioRef.current.duration || 0, audioRef.current.currentTime + seconds));
  }

  function togglePlay() {
    if (!audioRef.current) return;
    if (audioRef.current.paused) audioRef.current.play();
    else audioRef.current.pause();
  }

  function setPlaybackTime(t) {
    if (!audioRef.current) return;
    audioRef.current.currentTime = t;
  }

  function setPlaybackSpeed(s) {
    setSpeed(s);
    if (audioRef.current) audioRef.current.playbackRate = s;
  }

  // EPUB load
  async function loadEPUBHandle(fileHandle) {
    const ePubLib = await import('epubjs');
    const file = await fileHandle.getFile();
    const arrayBuf = await file.arrayBuffer();

    const book = ePubLib.default ? ePubLib.default(arrayBuf) : ePubLib(arrayBuf);
    epubRef.current = book;

    const rendition = book.renderTo('epub-viewer', { width: '100%', height: '100%' });
    renditionRef.current = rendition;

    rendition.themes.default({ 'body': { 'fontSize': `${fontSize}px`, 'lineHeight': lineHeight } });

    await book.ready;
    rendition.display();

    book.on('renderer:locationChanged', (location) => {
      // can map location to audio time if mapping contains cfi locators
    });

    rendition.on('selected', async (cfiRange, contents) => {
      try {
        const cfi = cfiRange.start ? cfiRange.start.cfi : (cfiRange.cfi || cfiRange);
        console.log('selected cfi', cfi);
      } catch (e) {
        console.warn(e);
      }
    });

    startHighlightLoop();
  }

  // PDF load
  async function loadPDFHandle(fileHandle) {
    const pdfjsLib = await import('pdfjs-dist/legacy/build/pdf');
    try {
      const worker = await import('pdfjs-dist/build/pdf.worker.entry');
      pdfjsLib.GlobalWorkerOptions.workerSrc = worker.default || worker;
    } catch (e) { }

    const file = await fileHandle.getFile();
    const array = await file.arrayBuffer();
    const loadingTask = pdfjsLib.getDocument({ data: array });
    const pdf = await loadingTask.promise;
    pdfDocumentRef.current = pdf;

    await renderPDFPages(pdf, pdfContainerRef.current);
    startHighlightLoop();
  }

  async function renderPDFPages(pdf, container) {
    container.innerHTML = '';
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const viewport = page.getViewport({ scale: 1.5 });
      const canvas = document.createElement('canvas');
      canvas.style.width = '100%';
      canvas.height = viewport.height;
      canvas.width = viewport.width;
      const ctx = canvas.getContext('2d');
      await page.render({ canvasContext: ctx, viewport }).promise;

      const textContent = await page.getTextContent();
      const textLayerDiv = document.createElement('div');
      textLayerDiv.className = 'pdf-text-layer';
      textLayerDiv.style.position = 'relative';
      textLayerDiv.style.padding = '8px 0';
      textContent.items.forEach((item, idx) => {
        const span = document.createElement('span');
        span.textContent = item.str + ' ';
        span.dataset.id = `p${p}_t${idx}`;
        span.style.userSelect = 'text';
        span.addEventListener('click', (e) => {
          handleTextClick({type:'pdf', page:p, itemIndex: idx});
        });
        textLayerDiv.appendChild(span);
      });

      const wrapper = document.createElement('div');
      wrapper.appendChild(canvas);
      wrapper.appendChild(textLayerDiv);
      container.appendChild(wrapper);
    }
  }

  function handleTextClick(locator) {
    if (!mapping) return;
    const found = mapping.find(m => m.locator === locatorToKey(locator));
    if (found) setPlaybackTime(found.start || 0);
  }

  function locatorToKey(locator) {
    if (!locator) return null;
    if (locator.type === 'pdf') return `pdf_p${locator.page}_i${locator.itemIndex}`;
    if (locator.cfi) return `cfi:${locator.cfi}`;
    return JSON.stringify(locator);
  }

  function parseSRTorVTT(text) {
    const lines = text.split(/\r?\n/);
    const out = [];
    let i = 0;
    while (i < lines.length) {
      const line = lines[i++].trim();
      if (!line) continue;
      if (/^\d+$/.test(line)) {
        const ts = lines[i++].trim();
        const [startS, endS] = ts.split(/\s+-->\s+/);
        const start = parseTimestamp(startS);
        const end = parseTimestamp(endS);
        let txt = '';
        while (i < lines.length && lines[i].trim()) {
          txt += (txt ? '\n' : '') + lines[i++];
        }
        out.push({ start, end, text: txt });
      } else if (line.includes('-->')) {
        const ts = line;
        const [startS, endS] = ts.split(/\s+-->\s+/);
        const start = parseTimestamp(startS);
        const end = parseTimestamp(endS);
        let txt = '';
        while (i < lines.length && lines[i].trim()) txt += (txt ? '\n' : '') + lines[i++];
        out.push({ start, end, text: txt });
      }
    }
    return out;
  }

  function parseTimestamp(s) {
    const m = s.trim().replace(',', '.').split(':');
    if (m.length === 3) {
      return Number(m[0]) * 3600 + Number(m[1]) * 60 + Number(m[2]);
    }
    return 0;
  }

  async function addManualMapping(locator) {
    if (!audioRef.current) return;
    const t = audioRef.current.currentTime;
    const key = locatorToKey(locator);
    const newMap = [...(mapping || []), { start: t, locator: key }];
    setMapping(newMap);
    await saveMappingToFolder(newMap);
  }

  async function saveMappingToFolder(map) {
    if (!directoryHandleRef.current) return;
    try {
      const handle = await directoryHandleRef.current.getFileHandle('sync.json', { create: true });
      const writable = await handle.createWritable();
      await writable.write(JSON.stringify(map, null, 2));
      await writable.close();
      alert('Sync mapping saved as sync.json in the folder');
    } catch (e) {
      console.error('Save mapping failed', e);
      alert('Could not save mapping to folder: ' + e.message);
    }
  }

  function startHighlightLoop() {
    cancelAnimationFrame(rafRef.current);
    const loop = () => {
      rafRef.current = requestAnimationFrame(loop);
      if (!audioRef.current || !mapping) return;
      const t = audioRef.current.currentTime;
      let idx = -1;
      for (let i = 0; i < mapping.length; i++) {
        if (mapping[i].start <= t) idx = i;
        else break;
      }
      if (idx >= 0) {
        const entry = mapping[idx];
        highlightLocator(entry.locator);
      }
    };
    loop();
  }

  function highlightLocator(locatorKey) {
    document.querySelectorAll('.highlighted-sync').forEach(el => el.classList.remove('highlighted-sync'));
    if (!locatorKey) return;
    if (locatorKey.startsWith('cfi:')) {
      const cfi = locatorKey.slice(4);
      try {
        renditionRef.current && renditionRef.current.annotations.remove('sync-highlight');
        renditionRef.current && renditionRef.current.annotations.highlight(cfi, {}, (e) => {}, 'sync-highlight');
      } catch (e) { }
    } else if (locatorKey.startsWith('pdf_p')) {
      const el = document.querySelector(`[data-pdf-locator="${locatorKey}"]`);
      if (el) {
        el.classList.add('highlighted-sync');
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      }
    }
  }

  function addBookmark() {
    const t = audioRef.current?.currentTime || 0;
    const b = { id: Date.now(), time: t, note: '' };
    setBookmarks(prev => { const n = [...prev, b]; localStorage.setItem('ab_bookmarks', JSON.stringify(n)); return n; });
  }

  function addNote(text) {
    const t = audioRef.current?.currentTime || 0;
    const n = { id: Date.now(), time: t, text };
    setNotes(prev => { const nn = [...prev, n]; localStorage.setItem('ab_notes', JSON.stringify(nn)); return nn; });
  }

  useEffect(() => {
    const bm = JSON.parse(localStorage.getItem('ab_bookmarks') || '[]');
    const nt = JSON.parse(localStorage.getItem('ab_notes') || '[]');
    setBookmarks(bm);
    setNotes(nt);
  }, []);

  useEffect(() => () => {
    cancelAnimationFrame(rafRef.current);
    if (audioRef.current) audioRef.current.pause();
  }, []);

  return (
    <div className={`min-h-screen p-4 ${theme === 'dark' ? 'bg-slate-900 text-white' : theme === 'sepia' ? 'bg-orange-50 text-slate-900' : 'bg-white text-slate-900'}`}>
      <header className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-semibold">Audiobook Sync — Read & Listen</h1>
        <div className="flex gap-2">
          <button className="btn" onClick={pickFolderAndLoad}>Open Folder</button>
          <select value={theme} onChange={e => setTheme(e.target.value)} className="input">
            <option value="light">Light</option>
            <option value="dark">Dark</option>
            <option value="sepia">Sepia</option>
          </select>
        </div>
      </header>

  (rest of file continues...)
